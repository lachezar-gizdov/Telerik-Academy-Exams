﻿namespace Academy.Models.Contracts
{
    public interface ILectureResouce
    {
        string Name { get; set; }

        string Url { get; set; }
    }
}
