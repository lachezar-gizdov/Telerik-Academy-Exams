﻿namespace Academy.Models
{
    using System;

    class User : IUser
    {
        public string Username { get; set; }
    }
}
